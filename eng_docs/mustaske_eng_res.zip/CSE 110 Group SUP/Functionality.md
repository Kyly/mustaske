Fullscreen Mode
———————
Create Room
—
+ Once the user has accessed mustaske.com, they will be prompted with the front page which allows them to Make a room as well as Join a room.
+ Making a room consists of the user typing in their desired room name and clicking “Make”
+ The user must share the “Room id”, which is found in the top right corner of your fullscreen page under “Room Options”.
+ On a minimized screen it is found on the top corner of your screen which consists of three horizontal white bars. 

Join Room
—
+ Once the user has accessed mustaske.com, they will be prompted with the front page which allows them to Make a room as well as Join a room.
+ The user needs to enter in the ‘Room id’, that is shared by the creator of the room, and click “Join” in order to join the room.

Delete Room (Owner)
—
+  Click on the “Room Options” which is found on the top right corner of the screen and click ‘Delete Room’. This feature allows the owner to get rid of the room and close the session.

Leave Room (Audience)
+  Click on the “Room Options” which is found on the top right corner of the screen and click “Leave Room”. This feature allows the owner to get rid of the room and close the session.

Top Questions (Owner)
+ These are displayed on the left side of the owner screen. This feature shows you the upvoted questions.

Recent Questions (Owner)
—
+ These are displayed on the right side of the owner screen. This feature shows you the recent questions that have been added by the users of the group.

Start Poll (Owner)
—
+ Click on the “Start Poll” button which is located on the top right part of the owner page. This feature allows the owner to start a poll for the audience members.

Stop Poll (Owner)
—
+ Click on the “Stop Poll” button which is located on the top right part of the owner page. This feature allows the owner to stop the poll for the audience members.

Poll Results (Owner)
—
+ Click on the “Poll Results” button which is located on the top right part of the owner page. This feature allows the the owner to view the poll results from the audience input.

Search Questions (Owner)
—
+  Click on the text field with the grayed out text ‘Search all questions’ and search your desired question.

Dismiss Question (Owner)
—
+ Click the “Dismiss Question” button  on the appropriate question they need to dismiss.

Warn User (Owner)
—
+ Click on the “Warn User” button which then shows the user a warning message.

Ban User (Owner)
—
+ If the user has been warned twice they will then be banned. Refer to Warn User (Owner) for further details.

Ask Question (Audience)
—
+ Click on the text field with the grayed out ‘ask a question!’ and ask your desired question by clicking enter once done typing or by clicking the mail icon at the end of the text box.

Format Question (Audience)
—
+ The user may modify their text by following the sample text formatting tips below the text field.

Vote on Poll (Audience)
—
+ If your voting screen went away, click on the “Vote on Poll” button at the top right of your screen and your answers choices will appear again.
+ It turns green if you have voted, and turns red if you have not yet voted.



Halfscreen Mode
———————
Create Room
—
+ Once the user has accessed mustaske.com, they will be prompted with the front page which allows them to Make a room as well as Join a room.
+ Making a room consists of the user typing in their desired room name and clicking “Make”
+ The user must share the ‘Room id’, which is found in the dropdown menu in the top left corner of the screen.
+ The dropdown menu will then become the ‘Room Options’ button when you enter fullscreen.

Join Room
—
+ Once the user has accessed mustaske.com, they will be prompted with the front page which allows them to Make a room as well as Join a room.
+ The user needs to enter in the ‘Room id’, that is shared by the creator of the room, and click “Join”.

Delete Room (Owner)
—
+  Click on the dropdown menu in the top left corner of the screen and click “Delete Room” which is found under the ‘Room Options’ tab. This feature allows the owner to get rid of the room and close the session.

Leave Room (Owner)
—
+  Click on the dropdown menu in the top left corner of the screen and click “Leave Room” which is found under the ‘Room Options’ tab. This feature allows the owner to get rid of the room and close the session.

Top Questions (Owner)
—
+ Click on the dropdown menu and click “Top Questions” which is found under the ‘Questions Options’ tab. This feature shows you the upvoted questions.

Recent Questions (Owner)
—
+ Click on the dropdown menu and click “Recent Questions” which is found under the ‘Questions Options’ tab. This feature shows you the recent questions that have been added by the users of the group.

Start Poll (Owner)
—
+ Click on the dropdown menu and click “Start Poll” which is found under the ‘Poll Options’ tab. This feature allows the owner to start a poll for the audience members.

Stop Poll (Owner)
—
+ Click on the dropdown menu and click “Stop Poll” which is found under the ‘Poll Options’ tab. This feature allows the owner to stop the poll for the audience members.

Poll Results (Owner)
—
+ Click on the dropdown menu and click “Poll Results” which is found under the ‘Poll Options’ tab. This feature allows the the owner to view the poll results from the audience input.

Search Questions (Owner)
—
+  Click on the dropdown menu and click the text field with the grayed out text ‘Search all questions’ which is found under the “Questions Options” tab. This feature allows the owner to search all of the questions.

Dismiss Question (Owner)
—
+ Click the “Dismiss Question” button  on the appropriate question they need to dismiss.

Warn User (Owner)
—
+ Click on the “Warn User” button which then shows the user a warning message.

Ban User (Owner)
—
+ If the user has been warned twice they will then be banned. Refer to Warn User (Owner) for further details.

Ask Question (Audience)
—
+ Click on the text field with the grayed out ‘ask a question!’ and ask your desired question by clicking enter once done typing or by clicking the mail icon at the end of the text box.

Format Question (Audience)
—
+ The user may modify their text by following the sample text formatting tips below the text field.

Vote on Poll (Audience)
—
+ If your voting screen went away, click on the “Vote on Poll” button at the bottom of the dropdown menu and your answers choices will appear again.
+ It turns green if you have voted, and turns red if you have not yet voted.
